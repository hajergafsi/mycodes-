﻿/****************************************************************************
**
**				ÖĞRENCİ ADI...Hajer  Gafsi..:
**				ÖĞRENCİ NUMARASI..B181210562.:
**				DERS GRUBU………B…:
****************************************************************************/
#include <iostream>
#include<iomanip>
#include<Windows.h>

using namespace std;
int main() {
	int satir, sutun, j;
	cout << "satir sayisini giriniz  ";
	cin >> satir;
	cout << endl;
	//satir sayisi 5 ile 15 arasi olmali kullanici bu aralikta olan bir sayi girene kadan ondan satir sayisi girmesini istenecek 
	while ((satir < 5) || (satir > 15)) {
		cout << "satir numarasi hatali...tekrar deneyin...";
		cin >> satir;
	}
	//sutun sayisi 5 ile 40 arasi olmali kullanici bu aralikta olan bir sayi girene kadan ondan sutun sayisi girmesini istenecek 
	cout << "sutun sayisini giriniz  ";
	cin >> sutun;
	cout << endl;
	while ((sutun < 5) || (sutun > 40)) {
		cout << "sutun numarasi hatali...tekrar deneyin...";
		cin >> sutun;
	} 
	//sutun sayisi satir sayisina iki kati olmasina saglar
	while ((sutun != (satir * 2))) {
		cout << "sutun satira iki kati olmalidir ...tekrar deneyin...";
		cin >> sutun;
	}
	cout << endl;
	//sutun sayisina kadar yildiz çiziyor ;
	for (int i = 0; i < sutun; i++) {
		cout << "*";
	}
	cout << endl;
	Sleep(100);
	j = sutun / 2;
	int k = 3;
	//bir uçgen çizecek sekilde yildizlar çiziyor 
	for (int i = 0; i < (satir - 2); i++) {
		cout << "*" << setw(j - 2) << "*" << setw(k) << "*" << setw(j - 2) << "*" << endl;
		j--; k = k + 2;
		Sleep(100);
	}
	//uçgenin altinda bir satir yildizlar çiziyor	 
	for (int i = 0; i < sutun; i++) {
		cout << "*";
	}
	Sleep(100);
	cout << endl << endl;
	// bir satir yildizlar çiziyor
	for (int i = 0; i < sutun; i++) {
		cout << "*";
	}
	cout << endl;
	Sleep(100);
	j = 1;
	//bir ters uçgen çizecek sekilde yildizlar çiziyor 
	for (int i = 0; i < (satir - 2); i++) {
		k = sutun - 2 * j - 1;

		cout << "*" << setw(j) << "*" << setw(k) << "*" << setw(j) << "*";
		Sleep(100);
		j++;
		cout << endl;
	}
	//uçgenin altinda bir satir yildizlar çiziyor	 
	for (int i = 0; i < sutun; i++) {
		cout << "*";
	}
	cout << endl;
	Sleep(100);
}
