﻿/****************************************************************************
**
**				ÖĞRENCİ ADI...........................: Hajer Gafsi
**				ÖĞRENCİ NUMARASI.............:B181210562
**				DERS GRUBU…………………:B
****************************************************************************/


#include<iostream>
#include<iomanip>
#include<math.h>
#include<ctime>
using namespace std;

void matrisiGoster(int[30][30], int);
void matriseDegerAt(int[30][30], int);
void SutunSatirDegistir(int[30][30], int,int,int);
void tekleriBasaAl(int[30][30],int,int);
void tersCevir(int[30][30], int, int);
void toplamlariYazdir(int[30][30], int);
void menu(int[30][30],int);

int main() {
	int n, Matris[30][30];
	cout << "matrisinin boyutunu giriniz : ";
	cin >> n;
	//while dongusu matrisinin boyutunu 5 ile 25 arasinda olmasini saglar 
	while ((n < 5) || (n > 25)) {
		cout << "matrisinin boyutu 5'den buyuk ve 25'den kucuk olmalidir " << endl;
		cin >> n;
	}
	matriseDegerAt(Matris, n);
	menu(Matris, n);
}

	//deger dondurmeyen 2 parametre alan matriseDegerAt adli fonksyon matrise 1-9 aralığında rastgele değerler atar. 
	void matriseDegerAt(int matris[30][30], int boyut) {
		srand(time(NULL));
		//asagidaki for dongusu matrisinin satirdan bir sonraki satira gecmek icin kullanilir 
		for (int i = 1; i <= boyut; i++) {
			//asagidaki for dongusu matrisinin elemanlara rastgele 1 ile 9 arasinda degerleri atar
			for (int j = 1; j <= boyut; j++) {
				matris[i][j] = ((rand() % 9) + 1);
			}
		}
	}
	//deger dondurmeyen iki parametre alan matrisiGoster adli fonksyonu matrisini ekrana yazdiriyor 
	void matrisiGoster(int mat[30][30], int boyut) {
		cout << setw(8) << 1;
		//asagidaki for dongusu matrisinin sutunlarinin numaralarini ekrana yazdiriyor 
		for (int i = 2; i <= boyut; i++) {
			cout << setw(5) << i;
		}
		cout << endl << setw(5);
		//asagidaki for dongusu matrisinin sutunlarindan altinda bir dogrusal cizgi ciziyor 
		for (int i = 0; i < boyut * 5 - 1; i++) {
			cout << "_";
		}
		cout << endl;
		//asagidaki for dongusu matrisinin satirlarinin numaralarini yazdiriyor 
		for (int i = 1; i <= boyut; i++) {
			cout << setw(1) << i << setw(2) << "|";
			//asagidaki for dongusu matrisinin elemanlari ekrana yazdiriyor 
			for (int j = 1; j <= boyut; j++) {
				cout << setw(5) << mat[i][j];
			}
			cout << endl << endl;

		}
	}
	//deger donfurmeyen 4 parametre alan satirSutunDegistir adli fonksyonu numaralarini disaridan girilen satir ve sutun içerisinde yer değiştirecektir
	void SutunSatirDegistir(int matris[30][30], int boyut, int sat, int sut) {
		int aux;
		for (int i = 1; i <= boyut; i++) {
			//if kosullu sutunun satirdan buyuk olup olmadigini bakiyor 
			if (sut > sat)
			{
				//if kosullu i nin degeri sutuna esit oldugu halinde hangi islem yapmasi gerektigini belirtiyor 
				if (i == sut) {
					aux = matris[i][i];
					matris[i][i] = matris[sat][sat];
					matris[sat][i] = matris[sat][i] + aux;

				}
				//if kosullu i nin degeri sutuna esit olmadigi halinde hangi islem yapmasi gerektigini belirtiyor
				else {
					aux = matris[i][sut];
					matris[i][sut] = matris[sat][i];
					matris[sat][i] = aux;
				}
			}
			//if kosullu satirin sutunundan  buyuk olup olmadigini bakiyor 
			else if (sat > sut) {
				//if kosullu i nin degeri satira esit oldugu halinde hangi islem yapmasi gerektigini belirtiyor 
				if (i == sat) {
					aux = matris[sat][i];
					matris[sat][i] = matris[sut][sut];
					matris[i][sut] = matris[i][sut] + aux;
				}
				//if kosullu i nin degeri sutuna esit olmadigi halinde hangi islem yapmasi gerektigini belirtiyor
				else {
					aux = matris[i][sut];
					matris[i][sut] = matris[sat][i];
					matris[sat][i] = aux;
				}
			}
		}
		matrisiGoster(matris, boyut);
	}
	//deger dondurmeyen 3 parametre alan tekleriBasaAl adli fonksyonun parametre olarak girilen satirin numarasina gore bu satirdaki 
	//elemanlarinin tek olanlari satrinin basinda  aliyor 
	void tekleriBasaAl(int matris[30][30], int satir, int boyut) {
		//for dongusu bu satirdaki elemanlari tek tek isliyor 
		for (int i = 1; i < boyut; i++) {
			//if kosuluyla elemanin cift oldugu zaman bir sonraki ilk tek sayiyla yer degistirmesini saglar
			if (matris[satir][i] % 2 == 0) {
				//for dongusu suandaki isledigi elemanindan itibaren satirdaki diger elemanlari isliyor 
				for (int j = i + 1; j <= boyut; j++) {
					//if kosulu elemanin tek oldugu halinde satrinin basina atiyor 
					if (matris[satir][j] % 2 == 1) {
						int aux = matris[satir][i];
						matris[satir][i] = matris[satir][j];
						matris[satir][j] = aux;
					}
				}
			}
		}
		matrisiGoster(matris, boyut);
	}
	//deger dondurmeyen 3 parametre alan tersCevir adli fonksyonun numurasini parametre olarak girilen sutunun elemanlari sutun 
	//icerisinde ters ceviriyor 
	void tersCevir(int matris[30][30], int sutun, int boyut) {
		//for dongusu islenen sutunun yarisina kadar elemanlarini tek tek isleniyor ve sutununun elemanlari sutun icerisinde ters ceviriyor
		for (int i = 1; i <= boyut / 2; i++) {
			int aux = matris[i][sutun];
			matris[i][sutun] = matris[boyut - i + 1][sutun];
			matris[boyut - i + 1][sutun] = aux;
		}
		matrisiGoster(matris, boyut);
	}
	//deger dondurmeyen 2 parametre alan toplamlariYazdir adli fonksyonu matrisin butun elemanlarinin toplamini hesaplaniyor ve 
	//toplamdan ilk elemani cikartarak o degere ilk elemana atiyor ve her elemanin bir öncekinden kendi değeri çıkartıyor
	void toplamlariYazdir(int matris[30][30], int boyut) {
		int toplam = 0;
		//asagidaki for dongusu matrisinin satirlari tek tek isliyor 
		for (int i = 1; i <= boyut; i++) {
			//asagidaki for dongusu matrisinin butun elemanlarin toplamini hesaplaniyor 
			for (int j = 1; j <= boyut; j++) {
				toplam = toplam + matris[i][j];
			}
		}
		matris[1][1] = toplam - matris[1][1];
		//asagidaki for dongusu birici satrinin her elemani bir öncekinden kendi değeri çıkartıyor  
		for (int i = 2; i <= boyut; i++) {
			matris[1][i] = matris[1][i - 1] - matris[1][i];
		}
		//asagidaki for dongusu diger satirlarinin her elemanin bir öncekinden kendi değeri çıkartıyor  
		for (int i = 2; i <= boyut; i++) {
			matris[i][1] = matris[i - 1][boyut] - matris[i][1];
			for (int j = 2; j <= boyut; j++) {
				matris[i][j] = matris[i][j - 1] - matris[i][j];
			}

		}
		matrisiGoster(matris, boyut);
	}
	//deger dondurmeyen iki parametre alan menu adli fonksyonu matrisi ve 4 secenekli bir menu ekrana yazdiriyor ve kullanicindan hangi isler 
	//yapmak istedigini istiyor
	void menu(int matris1[30][30] ,int n) {
		int rakam, satir, sutun;
		matrisiGoster(matris1 , n);
		cout << endl << "1. Sutun Satir Degistir : " << endl << "2. Tekleri basa al(satir) " << endl << "3. Ters Cevir " << endl << "4. toplamlari yazdir";
		cout << endl;
		cin >> rakam;
		//if kosulu kullanicinin 1 tusuna bastigi halinde menunun 1. secenegi calistiyor 
		if (rakam == 1) {
			cout << "satir sutun  ";
			cin >> satir >> sutun;
			//asagidaki if kosulluyla kullunici matrisinin boyutundan buyuk bir degeri girdigi zaman matrisi ve secenekleri ekrana
			//tekrar cikartiyor 
			if (satir > n) {
				cout << "Satir matris boyutundan büyük.   "<<endl ;
				menu(matris1, n);
			}
			//asagidaki if kosulluyla kullunici matrisinin boyutundan buyuk bir degeri girdigi zaman matrisi ve secenekleri ekrana
			//tekrar cikartiyor 
			else if (sutun > n) {
				cout << "Sutun matris boyutundan büyük.   "<<endl;
				menu(matris1, n);
			}
			else SutunSatirDegistir(matris1, n, satir, sutun);
		}
		//if kosulu kullanicinin 2 tusuna bastigi halinde menunun 1. secenegi calistiyor 
		else if (rakam == 2) {
			cout << "Satir numarasini giriniz = ";
			cin >> satir;
			//asagidaki if kosulluyla kullunici matrisinin boyutundan buyuk bir degeri girdigi zaman matrisi ve secenekleri ekrana
			//tekrar cikartiyor 
			if (satir > n) {
				cout << "Satir matris boyutundan büyük.     "<<endl ;
				menu(matris1, n);
			}
			else 
			tekleriBasaAl(matris1, satir, n);
		}
		//if kosulu kullanicinin 3 tusuna bastigi halinde menunun 1. secenegi calistiyor 
		else if (rakam == 3) {
			cout << "sutun numarasini giriniz = ";
			cin >> sutun;
			//asagidaki if kosulluyla kullunici matrisinin boyutundan buyuk bir degeri girdigi zaman matrisi ve secenekleri ekrana
			//tekrar cikartiyor 
			if (sutun > n) {
				cout << "Sutun matris boyutundan büyük.   "<<endl ;
				menu(matris1, n);
			}
			else 
			tersCevir(matris1, sutun, n);
		}
		//if kosulu kullanicinin 4 tusuna bastigi halinde menunun 1. secenegi calistiyor 
		else if (rakam == 4)
			toplamlariYazdir(matris1, n);	
}
