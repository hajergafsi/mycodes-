﻿/****************************************************************************
**
**				ÖĞRENCİ ADI...........................:Hajer Gafsi
**				ÖĞRENCİ NUMARASI.............:B181210562
**				DERS GRUBU…………………:1B
****************************************************************************/

#include <iostream> 
#include<math.h>
#include<ctime>
#include<iomanip>
#include<Windows.h> 
using namespace std;
//Sahnenin ozellikleri tutulan Sahne isimli 3 degisken den olusan bir yapi ;
struct	Sahne {
	int yukseklik;
	int genislik; 
	char kar;
};
//L seklinin ozellikleri tutulan LSekli isimli 4 degisken den olusan bir yapi ;
struct LSekli {
	int x;
	int y;
	int boyut;
	char karakter;
};
void kursoruGizle();
Sahne sahneOlustur();
void koordinatAta(int, int);
void sahneCiz(Sahne);
void lSekliCiz(LSekli);
LSekli lSekliOlustur();
LSekli lSekliAsagiGotur(LSekli);
int main() {
	LSekli sekil1;
	Sahne sahne1;
	sahne1 = sahneOlustur();
	//program çalıştığı sürece sahnenin sonuna geldiğinde tekrar başa dönmesini saglayan bir dongu.
	while (true)
	{
		kursoruGizle();
		sekil1= lSekliOlustur();
		system("cls");
		sahneCiz(sahne1);
		lSekliCiz(sekil1);
		Sleep(100);
		system("cls");
		sahneCiz(sahne1);
		// L şekli aşağı doğru hareket etmesini saglayan bir dongu.
		for (int p = sekil1.y + 1; p < sahne1.yukseklik - sekil1.boyut - 2; p++) {
			sekil1 = lSekliAsagiGotur(sekil1);
			lSekliCiz(sekil1);
			Sleep(100);
			system("cls");
			sahneCiz(sahne1);
		}
	koordinatAta(1, sahne1.yukseklik + 1);
	}
	return 0;
	system("pause");
}
//char tipinden bir degisken donduren karakteriSec isimli fonksyonu asagidaki 5 karakterlerinden bir tane rastgele seçer ve  dondurur
char karakteriSec() {
	char kar; 
srand(time(NULL));
char dizi[5];
dizi[0] = '*';
dizi[1] = '#';
dizi[2] = '$';
dizi[3] = '+';
dizi[4] = '@';
kar = dizi[rand() % 5];
return kar;
}

//Sahne tipinden bir degiskeni donduren sahneOlustur isimli fonksyonu sahnenin genisligi yuksekligi ve karakteri rastgele seçerek 
//bu sahneyi olusturur 
Sahne sahneOlustur() {
	srand(time(NULL));
	
	Sahne sahne;
	sahne.genislik = ((rand() % 3) + 3) * 10;
	sahne.yukseklik = rand() % 11 + 20;
	srand(time(NULL));
	sahne.kar = karakteriSec();
	return sahne;
}
//degeri dondurmeyen parametre olarak Sahne tipinden bir degiskeni alan sahneCiz isimli bir fonksyonu aldigi sahnenin ozelliklere 
//gore bu sahneyi çizer ;
void sahneCiz(Sahne sahne) {
	//asagidaki dongu sahnenin 1. satiri çizer 
	for (int i = 0; i < sahne.genislik; i++) {
		cout << sahne.kar;
	}
	cout << endl;
	//asagidaki dongu sahnenin 1. sutunu çizer 
	for (int i = 1; i < sahne.yukseklik - 1; i++) {
		cout << sahne.kar<< endl;
	}
	//asagidaki dongu sahneyi sinirlenecek sekilde sahnenin son sutunu çizer 
	for (int i = 0; i < sahne.yukseklik - 1; i++) {
		koordinatAta(sahne.genislik, i);
		cout << sahne.kar<<endl;
	}
	//asagidaki dongu sahneyi sinirlenecek sekilde sahnenin son satiri çizer
	for (int i = 0; i < sahne.genislik + 1; i++) {
		cout << sahne.kar;
	}
	cout << endl;
}
//LSekli tipinden bir degiskeni donduren lSekliOlustur isimli fonksyonu seklinin koordinatini tutacak olan x ve y degiskenleri   ve
//karakteri rastgele seçerek bu sekli olusturur
LSekli lSekliOlustur() {
	LSekli sekil;
	srand(time(NULL));
	sekil.x = (rand() % 21) + 5;
	sekil.y = 3;
	sekil.boyut = rand() % 6 + 2;
	sekil.karakter = karakteriSec();
	return sekil;
}
//x ve y degiskenleri parametre olarak alan bu fonksyonu Ekranda istedigimiz koordinata karakter cikarmak için kullanilir
void koordinatAta(int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;

	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
//degeri dondurmeyen parametre olarak LSekli tipinden bir degiskeni alan lSekliCiz isimli bir fonksyonu aldigi L seklinin ozelliklere 
//gore bu sekli çizer ;
void lSekliCiz(LSekli sekil) {
	//asagidaki kosul seklinin boyutunu 2 ye esit olmasi halinde cizmesini saglar 
	if (sekil.boyut == 2) {
		//asagidaki dongu seklinin cizmesini saglar 
		for (int i = 0; i < 3; i++) {
			koordinatAta(sekil.x, (sekil.y)++);
			cout << sekil.karakter;
		}
		cout << sekil.karakter;
	}
	//asagidaki kosul seklinin boyutunu 2 den farkli olmasi halinde cizmesini saglar 
	else {
		koordinatAta(sekil.x, sekil.y);
		//asagidaki dongu seklinin 1. satiri cizmesini saglar 
		for (int i = 0; i < sekil.boyut / 2 + 1; i++) {
			cout << sekil.karakter;
		}
		int j = sekil.y + 1;
		//asagidaki dongu seklinin yarisini cizmesini saglar 
		for (int i = 0; i < sekil.boyut / 2 + 1; i++) {
			koordinatAta(sekil.x, j);
			cout << sekil.karakter << setw(sekil.boyut / 2) << sekil.karakter;
			j++;
		}
		//asagidaki kosul seklinin boyutunu cift olmasi halinde cizmesini saglar 
		if (sekil.boyut % 2 == 0) {
			//asagidaki dongu L seklinin alt kisminin cizmesinin baslamasini saglar
			for (int i = 0; i < sekil.boyut / 2 - 1; i++) {
				cout << sekil.karakter;
			}
		}
		//asagidaki kosul seklinin boyutunu tek olmasi halinde cizmesini saglar 
		else {
			for (int i = 0; i < sekil.boyut / 2; i++) {
				cout << sekil.karakter;
			}
		}

		koordinatAta(sekil.x, j);
		//asagidaki dongu seklinin kalan kisminin cizmesini saglar 
		for (int i = 0; i < sekil.boyut / 2 - 1; i++) {
			cout << sekil.karakter << setw(sekil.boyut - 1) << sekil.karakter;
			j++;
			koordinatAta(sekil.x, j);
		}
		//asagidaki dongu seklinin son satirinin cizmesini saglar 
		for (int i = 0; i < sekil.boyut; i++)
			cout << sekil.karakter;
	}
}
//lSekliAsagiGotur fonksiyon parametre olarak aldigi LSekli yapisini tipinden bir degiskeni bu sekli bir birim asagida çizilecek 
//sekilde yapisini degistirir ve degistirdigi yapıyı geri dondurmelidir.
LSekli lSekliAsagiGotur(LSekli sekil) {
	sekil.y++;
	return sekil;
}
void kursoruGizle() {
	HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO cursorInfo;
	GetConsoleCursorInfo(out, &cursorInfo);
}

